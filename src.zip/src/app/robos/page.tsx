"use client";

import { useEffect, useMemo, useState } from "react";

import AppShell from "@/components/layout/AppShell";
import RobotHeader from "@/components/robos/RobotHeader";
import RobotTable, { Robot } from "@/components/robos/RobotTable";
import RobotDetails from "@/components/robos/RobotDetails";
import RobotDrawer from "@/components/robos/RobotDrawer";
import { robotsMock } from "@/components/robos/robots.mock";
import RobotForm, { RobotFormData,} from "@/components/robos/RobotForm";

const ambientes = [
  "Todos",
  "Produção",
  "Teste",
  "Desenvolvimento",
] as const;

type DrawerMode = "create" | "edit";

export default function RobosPage() {
  const [pesquisa, setPesquisa] = useState("");
  const [ambiente, setAmbiente] = useState("Todos");
  const [sistema, setSistema] = useState("Todos");

  const [selectedRobot, setSelectedRobot] =
    useState<Robot | null>(null);

  const [drawerOpen, setDrawerOpen] =
    useState(false);

  const [drawerMode, setDrawerMode] =
    useState<DrawerMode>("edit");

  const [robots, setRobots] =
    useState<Robot[]>(robotsMock);

const sistemas = useMemo(() => {
  return [
    "Todos",
    ...Array.from(
      new Set(
        robots.map((robot) => robot.sistema)
      )
    ).sort(),
  ];
}, [robots]);

  const robotsFiltrados = useMemo(() => {
return robots.filter((robot) => {
        const busca =
        robot.nome
          .toLowerCase()
          .includes(pesquisa.toLowerCase()) ||
        robot.sistema
          .toLowerCase()
          .includes(pesquisa.toLowerCase());

      const filtroAmbiente =
        ambiente === "Todos" ||
        robot.ambiente === ambiente;

      const filtroSistema =
        sistema === "Todos" ||
        robot.sistema === sistema;

      return (
        busca &&
        filtroAmbiente &&
        filtroSistema
      );
    });
  }, [pesquisa, ambiente, sistema]);

  useEffect(() => {
    if (robotsFiltrados.length === 0) {
      setSelectedRobot(null);
      return;
    }

    if (
      !selectedRobot ||
      !robotsFiltrados.some(
        (r) => r.id === selectedRobot.id
      )
    ) {
      setSelectedRobot(robotsFiltrados[0]);
    }
  }, [robotsFiltrados, selectedRobot]);

  function fecharDrawer() {
  setDrawerOpen(false);
}

function salvarRobot(data: RobotFormData) {
  if (drawerMode === "create") {
const novoRobot: Robot = {
  id: Date.now(),
  nome: data.nome,
  sistema: data.sistema,
  pacote: data.pacote,
  ambiente: data.ambiente,
      ultimaPublicacao: new Date().toLocaleDateString("pt-BR"),
      descricao: data.descricao,
      stack: data.stack,
      fila: data.fila,
      versao: data.versao,
      responsavel: data.responsavel,
      ativo: data.ativo,
    };

    setRobots((old) => [...old, novoRobot]);
    setSelectedRobot(novoRobot);
    fecharDrawer();

    return;
  }

  if (!selectedRobot) return;

  const robotAtualizado: Robot = {
    ...selectedRobot,
    nome: data.nome,
    sistema: data.sistema,
    pacote: data.pacote,
    ambiente: data.ambiente,
    descricao: data.descricao,
    stack: data.stack,
    fila: data.fila,
    versao: data.versao,
    responsavel: data.responsavel,
    ativo: data.ativo,
  };

  setRobots((old) =>
    old.map((robot) =>
      robot.id === robotAtualizado.id
        ? robotAtualizado
        : robot
    )
  );

  setSelectedRobot(robotAtualizado);

  fecharDrawer();
}

  return (
    <>
      <AppShell title="Robôs">
        <RobotHeader
          pesquisa={pesquisa}
          onPesquisaChange={setPesquisa}
          ambiente={ambiente}
          ambientes={ambientes}
          onAmbienteChange={setAmbiente}
          sistema={sistema}
          sistemas={sistemas}
          onSistemaChange={setSistema}
          totalRobots={robotsFiltrados.length}
          onNovoRobot={() => {
            setDrawerMode("create");
            setDrawerOpen(true);
          }}
        />

        <div
          style={{
            display: "flex",
            gap: 24,
            marginTop: 24,
            alignItems: "stretch",
          }}
        >
          <div
            style={{
              width: "38%",
              minWidth: 360,
            }}
          >
            <RobotTable
              robots={robotsFiltrados}
              selectedRobot={selectedRobot}
              onSelectRobot={setSelectedRobot}
            />
          </div>

          <div
            style={{
              flex: 1,
            }}
          >
            <RobotDetails
  robot={selectedRobot}
  onEdit={(robot) => {
    setSelectedRobot(robot);
    setDrawerMode("edit");
    setDrawerOpen(true);
  }}
/>
          </div>
        </div>
      </AppShell>

      <RobotDrawer
        open={drawerOpen}
        title={
          drawerMode === "create"
            ? "Novo Robô"
            : "Editar Robô"
        }
        onClose={() => setDrawerOpen(false)}
      >
<RobotForm
  key={drawerMode + (selectedRobot?.id ?? "new")}
  nome={
    drawerMode === "edit"
      ? selectedRobot?.nome
      : undefined
  }
  sistema={
    drawerMode === "edit"
      ? selectedRobot?.sistema
      : undefined
  }
  pacote={
  drawerMode === "edit"
    ? selectedRobot?.pacote
    : undefined
}
  ambiente={
    drawerMode === "edit"
      ? selectedRobot?.ambiente
      : undefined
  }
  descricao={
    drawerMode === "edit"
      ? selectedRobot?.descricao
      : undefined
  }
  stack={
    drawerMode === "edit"
      ? selectedRobot?.stack
      : undefined
  }
  fila={
    drawerMode === "edit"
      ? selectedRobot?.fila
      : undefined
  }
  versao={
    drawerMode === "edit"
      ? selectedRobot?.versao
      : undefined
  }
  responsavel={
    drawerMode === "edit"
      ? selectedRobot?.responsavel
      : undefined
  }
  ativo={
    drawerMode === "edit"
      ? selectedRobot?.ativo
      : true
  }
  submitText={
    drawerMode === "create"
      ? "Cadastrar Robô"
      : "Salvar Alterações"
  }
  isEdit={drawerMode === "edit"}
  onCancel={fecharDrawer}
  onDelete={() => {
    console.log("Excluir robô");
  }}
  onSubmit={salvarRobot}
/>
      </RobotDrawer>
    </>
  );
}