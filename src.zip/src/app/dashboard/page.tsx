import AppShell from "@/components/layout/AppShell";
import Feed from "@/components/dashboard/Feed";
import StatsCards from "@/components/dashboard/StatsCards";

export default function DashboardPage() {
  return (
    <AppShell title="Dashboard">
      <div
        style={{
          display: "flex",
          flexDirection: "column",
          gap: "32px",
        }}
      >
        <div>
          <h2
            style={{
              color: "#F8FAFC",
              fontSize: "32px",
              marginBottom: "8px",
            }}
          >
            Dashboard
          </h2>

          <p
            style={{
              color: "#94A3B8",
              fontSize: "16px",
            }}
          >
            Acompanhe todas as atualizações do Robot Center.
          </p>
        </div>

        <StatsCards />

        <Feed />
      </div>
    </AppShell>
  );
}