interface TopbarProps {
  title: string;
}

export default function Topbar({ title }: TopbarProps) {
  return (
    <header
      style={{
        height: "64px",
        background: "#111827",
        borderBottom: "1px solid #273449",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "0 32px",
      }}
    >
      <h1
        style={{
          color: "#F8FAFC",
          fontSize: "24px",
          fontWeight: 600,
          margin: 0,
        }}
      >
        {title}
      </h1>

      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: "16px",
        }}
      >
        <input
          type="text"
          placeholder="Pesquisar..."
          style={{
            width: "260px",
            height: "40px",
            background: "#1E293B",
            border: "1px solid #273449",
            borderRadius: "12px",
            padding: "0 14px",
            color: "#F8FAFC",
            outline: "none",
          }}
        />

        <div
          style={{
            color: "#F8FAFC",
            fontWeight: 500,
          }}
        >
          Marcos Souza
        </div>
      </div>
    </header>
  );
}