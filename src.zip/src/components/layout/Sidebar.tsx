import Link from "next/link";

export default function Sidebar() {
  return (
    <aside
      style={{
        width: "260px",
        background: "#111827",
        color: "#F8FAFC",
        display: "flex",
        flexDirection: "column",
        justifyContent: "space-between",
        borderRight: "1px solid #273449",
      }}
    >
      <div>
        <div
          style={{
            padding: "24px",
            borderBottom: "1px solid #273449",
          }}
        >
          <h2
            style={{
              fontSize: "20px",
              fontWeight: 700,
            }}
          >
            Robot Center
          </h2>

          <p
            style={{
              fontSize: "13px",
              color: "#94A3B8",
              marginTop: "4px",
            }}
          >
            Painel de Robôs Integradores
          </p>
        </div>

        <nav
          style={{
            display: "flex",
            flexDirection: "column",
            padding: "16px",
            gap: "8px",
          }}
        >
          <Link href="/dashboard" style={menuStyle}>
            Dashboard
          </Link>

          <Link href="/robos" style={menuStyle}>
            Robôs
          </Link>

          <Link href="/configuracoes" style={menuStyle}>
            Configurações
          </Link>
        </nav>
      </div>

      <div
        style={{
          padding: "24px",
          borderTop: "1px solid #273449",
          fontSize: "13px",
          color: "#94A3B8",
        }}
      >
        <div>Robot Center</div>
        <div>v0.0.3</div>
      </div>
    </aside>
  );
}

const menuStyle = {
  color: "#F8FAFC",
  textDecoration: "none",
  padding: "12px 16px",
  borderRadius: "12px",
  transition: "0.2s",
};