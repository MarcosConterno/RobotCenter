export default function Feed() {
  return (
    <section
      style={{
        flex: 1,
      }}
    >
      <h2
        style={{
          color: "#F8FAFC",
          fontSize: "24px",
          marginBottom: "8px",
        }}
      >
        Feed de Atualizações
      </h2>

      <p
        style={{
          color: "#94A3B8",
          marginBottom: "24px",
        }}
      >
        Últimas publicações realizadas no Robot Center.
      </p>

      <article
        style={{
          background: "#1E293B",
          border: "1px solid #273449",
          borderRadius: "12px",
          padding: "24px",
        }}
      >
        <div
          style={{
            color: "#60A5FA",
            fontWeight: 600,
            marginBottom: "16px",
          }}
        >
          🤖 Novo Robô
        </div>

        <h3
          style={{
            color: "#FFFFFF",
            fontSize: "22px",
            marginBottom: "16px",
          }}
        >
          Cadastro de Documentos
        </h3>

        <p
          style={{
            color: "#CBD5E1",
            lineHeight: 1.7,
            marginBottom: "24px",
          }}
        >
          O robô Cadastro de Documentos foi publicado em ambiente de Produção
          para a seguradora Allianz.
        </p>

        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <span
            style={{
              color: "#94A3B8",
            }}
          >
            há 2 horas
          </span>

          <button
            style={{
              background: "transparent",
              border: "none",
              color: "#60A5FA",
              cursor: "pointer",
              fontWeight: 600,
            }}
          >
            Ver detalhes →
          </button>
        </div>
      </article>
    </section>
  );
}