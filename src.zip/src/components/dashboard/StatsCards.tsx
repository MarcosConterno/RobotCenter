import {
  Bot,
  Rocket,
  FlaskConical,
  Code2,
} from "lucide-react";

const cards = [
  {
    icon: Bot,
    title: "Total Robôs",
    value: "23",
    subtitle: "Robôs cadastrados",
    color: "#3B82F6",
  },
  {
    icon: Rocket,
    title: "Produção",
    value: "12",
    subtitle: "Em ambiente produtivo",
    color: "#22C55E",
  },
  {
    icon: FlaskConical,
    title: "Em Teste",
    value: "7",
    subtitle: "Em homologação",
    color: "#F59E0B",
  },
  {
    icon: Code2,
    title: "Em Desenvolvimento",
    value: "4",
    subtitle: "Em desenvolvimento",
    color: "#8B5CF6",
  },
];

export default function StatsCards() {
  return (
    <div
      style={{
        display: "grid",
        gridTemplateColumns: "repeat(4, 1fr)",
        gap: "20px",
      }}
    >
      {cards.map((card) => {
        const Icon = card.icon;

        return (
          <div
            key={card.title}
            style={{
              background: "#1E293B",
              border: "1px solid #273449",
              borderRadius: "12px",
              padding: "24px",
            }}
          >
            <div
              style={{
                display: "flex",
                alignItems: "center",
                gap: "16px",
                marginBottom: "20px",
              }}
            >
              <div
                style={{
                  width: "52px",
                  height: "52px",
                  borderRadius: "12px",
                  background: `${card.color}20`,
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                }}
              >
                <Icon
                  size={24}
                  color={card.color}
                />
              </div>

              <div>
                <div
                  style={{
                    color: "#94A3B8",
                    fontSize: "14px",
                  }}
                >
                  {card.title}
                </div>

                <div
                  style={{
                    color: "#FFFFFF",
                    fontSize: "38px",
                    fontWeight: 700,
                    lineHeight: 1,
                    marginTop: "6px",
                  }}
                >
                  {card.value}
                </div>
              </div>
            </div>

            <div
              style={{
                color: "#64748B",
                fontSize: "14px",
              }}
            >
              {card.subtitle}
            </div>
          </div>
        );
      })}
    </div>
  );
}