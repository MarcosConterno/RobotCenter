import { Calendar, Cpu } from "lucide-react";
import { Robot } from "./RobotTable";

interface RobotCardProps {
  robot: Robot;
  selected?: boolean;
  onClick?: () => void;
}

const environmentColor = {
  Produção: "#22C55E",
  Teste: "#F59E0B",
  Desenvolvimento: "#3B82F6",
} as const;

export default function RobotCard({
  robot,
  selected = false,
  onClick,
}: RobotCardProps) {
  return (
    <div
      onClick={onClick}
      style={{
        cursor: "pointer",
        userSelect: "none",
        transition: "all .2s ease",
        background: selected ? "#223247" : "#1E293B",
        border: selected
          ? "1px solid #3B82F6"
          : "1px solid #273449",
        borderRadius: 12,
        padding: 18,
        boxShadow: selected
          ? "0 0 0 1px rgba(59,130,246,.20)"
          : "none",
      }}
    >
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
        }}
      >
        <div>
          <div
            style={{
              color: "#FFF",
              fontSize: 16,
              fontWeight: 600,
              marginBottom: 6,
            }}
          >
            {robot.nome}
          </div>

          <div
            style={{
              color: "#94A3B8",
              fontSize: 14,
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Cpu size={14} />
            {robot.sistema}
          </div>
        </div>

        <span
          style={{
            background: environmentColor[robot.ambiente],
            color: "#FFF",
            fontSize: 12,
            fontWeight: 600,
            padding: "4px 10px",
            borderRadius: 20,
            whiteSpace: "nowrap",
          }}
        >
          {robot.ambiente}
        </span>
      </div>

      <div
        style={{
          marginTop: 18,
          display: "flex",
          alignItems: "center",
          gap: 6,
          color: "#94A3B8",
          fontSize: 13,
        }}
      >
        <Calendar size={14} />
        {robot.ultimaPublicacao}
      </div>
    </div>
  );
}