interface RobotDrawerProps {
  open: boolean;
  title?: string;
  onClose: () => void;
  children?: React.ReactNode;
}

export default function RobotDrawer({
  open,
  title = "Drawer",
  onClose,
  children,
}: RobotDrawerProps) {
  if (!open) return null;

  return (
    <>
      {/* Overlay */}
      <div
        onClick={onClose}
        style={{
          position: "fixed",
          inset: 0,
          background: "rgba(0,0,0,.45)",
          zIndex: 999,
        }}
      />

      {/* Drawer */}
      <div
        style={{
          position: "fixed",
          top: 0,
          right: 0,
          width: 460,
          maxWidth: "100%",
          height: "100vh",
          background: "#1E293B",
          borderLeft: "1px solid #273449",
          zIndex: 1000,
          display: "flex",
          flexDirection: "column",
          boxShadow: "-8px 0 24px rgba(0,0,0,.35)",
        }}
      >
        {/* Cabeçalho */}
        <div
          style={{
            padding: "22px 24px",
            borderBottom: "1px solid #273449",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <h2
            style={{
              margin: 0,
              color: "#FFF",
              fontSize: 20,
            }}
          >
            {title}
          </h2>

          <button
            onClick={onClose}
            style={{
              width: 36,
              height: 36,
              borderRadius: 8,
              border: "1px solid #334155",
              background: "#162130",
              color: "#FFF",
              cursor: "pointer",
              fontSize: 18,
            }}
          >
            ✕
          </button>
        </div>

        {/* Conteúdo */}
        <div
          style={{
            flex: 1,
            overflow: "auto",
            padding: 24,
          }}
        >
          {children}
        </div>
      </div>
    </>
  );
}