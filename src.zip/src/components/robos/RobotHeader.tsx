"use client";

import { ChevronDown, Plus, Search } from "lucide-react";
import { useEffect, useRef, useState } from "react";

interface RobotHeaderProps {
  pesquisa: string;
  onPesquisaChange: (value: string) => void;

  ambiente: string;
  ambientes: readonly string[];
  onAmbienteChange: (value: string) => void;

  sistema: string;
  sistemas: string[];
  onSistemaChange: (value: string) => void;

  totalRobots: number;

  onNovoRobot?: () => void;
}

export default function RobotHeader({
  pesquisa,
  onPesquisaChange,
  ambiente,
  ambientes,
  onAmbienteChange,
  sistema,
  sistemas,
  onSistemaChange,
  totalRobots,
  onNovoRobot,
}: RobotHeaderProps) {
  const [open, setOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClick(e: MouseEvent) {
      if (
        menuRef.current &&
        !menuRef.current.contains(e.target as Node)
      ) {
        setOpen(false);
      }
    }

    document.addEventListener("mousedown", handleClick);

    return () =>
      document.removeEventListener("mousedown", handleClick);
  }, []);

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 24,
        marginBottom: 32,
      }}
    >
      {/* Cabeçalho */}

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <div>
          <h1
            style={{
              color: "#FFF",
              fontSize: 40,
              fontWeight: 700,
              marginBottom: 6,
            }}
          >
            Robôs
          </h1>

          <p
            style={{
              color: "#94A3B8",
            }}
          >
            Gerencie todos os robôs cadastrados.
          </p>
        </div>

        <button
          onClick={onNovoRobot}
          style={{
            display: "flex",
            alignItems: "center",
            gap: 8,
            background: "#2563EB",
            color: "#FFF",
            border: "none",
            borderRadius: 10,
            padding: "12px 18px",
            cursor: "pointer",
            fontWeight: 600,
          }}
        >
          <Plus size={18} />
          Novo Robô
        </button>
      </div>

      {/* Pesquisa */}

      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 18,
        }}
      >
        <div
          style={{
            position: "relative",
            width: 420,
          }}
        >
          <Search
            size={18}
            color="#64748B"
            style={{
              position: "absolute",
              top: "50%",
              left: 16,
              transform: "translateY(-50%)",
            }}
          />

          <input
            value={pesquisa}
            onChange={(e) =>
              onPesquisaChange(e.target.value)
            }
            placeholder="Pesquisar robô..."
            style={{
              width: "100%",
              background: "#1E293B",
              color: "#FFF",
              border: "1px solid #273449",
              borderRadius: 10,
              padding: "14px 16px 14px 46px",
              outline: "none",
            }}
          />
        </div>

        <div
          style={{
            color: "#94A3B8",
          }}
        >
          <strong
            style={{
              color: "#FFF",
            }}
          >
            {totalRobots}
          </strong>{" "}
          encontrados
        </div>
      </div>

      {/* Filtros */}

      <div
        style={{
          display: "flex",
          alignItems: "center",
          gap: 10,
          flexWrap: "wrap",
        }}
      >
        {ambientes.map((item) => {
          const ativo = ambiente === item;

          return (
            <button
              key={item}
              onClick={() => onAmbienteChange(item)}
              style={{
                background: ativo ? "#2563EB" : "#1E293B",
                color: "#FFF",
                border: ativo
                  ? "1px solid #2563EB"
                  : "1px solid #334155",
                borderRadius: 999,
                padding: "10px 18px",
                cursor: "pointer",
                fontWeight: 600,
              }}
            >
              {item}
            </button>
          );
        })}

        {/* Dropdown Sistema */}

        <div
          ref={menuRef}
          style={{
            position: "relative",
          }}
        >
          <button
            onClick={() => setOpen(!open)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              background: "#1E293B",
              color: "#FFF",
              border: "1px solid #334155",
              borderRadius: 999,
              padding: "10px 18px",
              cursor: "pointer",
              fontWeight: 600,
            }}
          >
            {sistema}

            <ChevronDown size={16} />
          </button>

          {open && (
            <div
              style={{
                position: "absolute",
                top: 48,
                right: 0,
                width: 220,
                background: "#1E293B",
                border: "1px solid #334155",
                borderRadius: 12,
                overflow: "hidden",
                zIndex: 999,
                boxShadow:
                  "0 15px 40px rgba(0,0,0,.35)",
              }}
            >
              {sistemas.map((item) => (
                <div
                  key={item}
                  onClick={() => {
                    onSistemaChange(item);
                    setOpen(false);
                  }}
                  style={{
                    padding: "12px 16px",
                    cursor: "pointer",
                    color:
                      sistema === item
                        ? "#60A5FA"
                        : "#FFF",
                    background:
                      sistema === item
                        ? "#233044"
                        : "transparent",
                  }}
                >
                  {item}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}