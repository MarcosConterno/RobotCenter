import RobotCard from "./RobotCard";

export interface Robot {
  id: number;

  // Informações Gerais
  nome: string;
  sistema: string;
  pacote: string;
  ambiente: string;
  ultimaPublicacao: string;
  descricao: string;

  // Execução
  stack: string;
  fila: string;
  versao: string;

  // Administração
  responsavel: string;
  ativo: boolean;
}

interface RobotTableProps {
  robots: Robot[];
  selectedRobot: Robot | null;
  onSelectRobot: (robot: Robot) => void;
}

export default function RobotTable({
  robots,
  selectedRobot,
  onSelectRobot,
}: RobotTableProps) {
  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 12,
      }}
    >
      {robots.map((robot) => (
        <RobotCard
          key={robot.id}
          robot={robot}
          selected={selectedRobot?.id === robot.id}
          onClick={() => onSelectRobot(robot)}
        />
      ))}
    </div>
  );
}