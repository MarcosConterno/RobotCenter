"use client";

import { useEffect, useState } from "react";

export interface RobotFormData {
  nome: string;
  sistema: string;
  pacote: string;
  ambiente: string;
  descricao: string;
  stack: string;
  fila: string;
  versao: string;
  responsavel: string;
  ativo: boolean;
}

interface RobotFormProps {
  nome?: string;
  sistema?: string;
  pacote?: string;
  ambiente?: string;
  descricao?: string;
  stack?: string;
  fila?: string;
  versao?: string;
  responsavel?: string;
  ativo?: boolean;

  submitText?: string;
  isEdit?: boolean;

  onCancel?: () => void;
  onDelete?: () => void;
  onSubmit?: (data: RobotFormData) => void;
}

export default function RobotForm({
  nome = "",
  sistema = "",
  pacote = "",
  ambiente = "Produção",
  descricao = "",
  stack = "",
  fila = "",
  versao = "",
  responsavel = "",
  ativo = true,
  submitText = "Salvar",
  isEdit = false,
  onCancel,
  onDelete,
  onSubmit,
}: RobotFormProps) {
const [form, setForm] = useState<RobotFormData>({
  nome,
  sistema,
  pacote,
  ambiente,
  descricao,
  stack,
  fila,
  versao,
  responsavel,
  ativo,
});

useEffect(() => {
  setForm({
    nome,
    sistema,
    pacote,
    ambiente,
    descricao,
    stack,
    fila,
    versao,
    responsavel,
    ativo,
  });
}, [
  nome,
  sistema,
  pacote,
  ambiente,
  descricao,
  stack,
  fila,
  versao,
  responsavel,
  ativo,
]);

  function update<K extends keyof RobotFormData>(
    field: K,
    value: RobotFormData[K]
  ) {
    setForm((old) => ({
      ...old,
      [field]: value,
    }));
  }

  return (
    <div
      style={{
        display: "flex",
        flexDirection: "column",
        gap: 26,
      }}
    >
      <SectionTitle title="Informações Gerais" />

      <Field
        label="Nome"
        placeholder="Nome do robô"
        value={form.nome}
        onChange={(v) => update("nome", v)}
      />

      <Field
        label="Sistema"
        placeholder="Ex.: Allianz"
        value={form.sistema}
        onChange={(v) => update("sistema", v)}
      />

      <Field
        label="Pacote"
        placeholder="Ex.: Documentos"
        value={form.pacote}
        onChange={(v) => update("pacote", v)}
      />

      <div>
        <label style={labelStyle}>Ambiente</label>
        <select
          value={form.ambiente}
          onChange={(e) =>
            update("ambiente", e.target.value)
          }
          style={selectStyle}
        >
          <option>Produção</option>
          <option>Teste</option>
          <option>Desenvolvimento</option>
        </select>
      </div>

      <div>
        <label style={labelStyle}>Descrição</label>

        <textarea
          value={form.descricao}
          onChange={(e) =>
            update("descricao", e.target.value)
          }
          rows={5}
          style={textareaStyle}
        />
      </div>

      <SectionTitle title="Configuração Técnica" />

      <Field
        label="Stack"
        placeholder=".NET 8"
        value={form.stack}
        onChange={(v) => update("stack", v)}
      />

      <Field
        label="Fila"
        placeholder="AWS SQS"
        value={form.fila}
        onChange={(v) => update("fila", v)}
      />

      <Field
        label="Versão"
        placeholder="1.0.0"
        value={form.versao}
        onChange={(v) => update("versao", v)}
      />

      <SectionTitle title="Controle" />

      <Field
        label="Responsável"
        placeholder="Nome do responsável"
        value={form.responsavel}
        onChange={(v) => update("responsavel", v)}
      />

      <div>
        <label style={labelStyle}>Ativo</label>

        <label
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            color: "#FFF",
            marginTop: 8,
          }}
        >
          <input
            type="checkbox"
            checked={form.ativo}
            onChange={(e) =>
              update("ativo", e.target.checked)
            }
          />

          Robô ativo
        </label>
      </div>

      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          marginTop: 12,
        }}
      >
        <div>
          {isEdit && (
            <button
              onClick={onDelete}
              style={{
                padding: "10px 18px",
                borderRadius: 8,
                border: "1px solid #DC2626",
                background: "#B91C1C",
                color: "#FFF",
                cursor: "pointer",
                fontWeight: 600,
              }}
            >
              Excluir Robô
            </button>
          )}
        </div>

        <div
          style={{
            display: "flex",
            gap: 12,
          }}
        >
          <button
            onClick={onCancel}
            style={{
              padding: "10px 18px",
              borderRadius: 8,
              border: "1px solid #475569",
              background: "transparent",
              color: "#FFF",
              cursor: "pointer",
            }}
          >
            Cancelar
          </button>

          <button
            onClick={() => onSubmit?.(form)}
            style={{
              padding: "10px 18px",
              borderRadius: 8,
              border: "none",
              background: "#2563EB",
              color: "#FFF",
              cursor: "pointer",
              fontWeight: 600,
            }}
          >
            {submitText}
          </button>
        </div>
      </div>
    </div>
  );
}

function SectionTitle({
  title,
}: {
  title: string;
}) {
  return (
    <div
      style={{
        borderBottom: "1px solid #334155",
        paddingBottom: 8,
        marginTop: 6,
      }}
    >
      <span
        style={{
          color: "#60A5FA",
          fontWeight: 700,
          fontSize: 15,
        }}
      >
        {title}
      </span>
    </div>
  );
}

interface FieldProps {
  label: string;
  value: string;
  placeholder: string;
  onChange: (value: string) => void;
}

function Field({
  label,
  value,
  placeholder,
  onChange,
}: FieldProps) {
  return (
    <div>
      <label style={labelStyle}>{label}</label>

      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        style={inputStyle}
      />
    </div>
  );
}

const labelStyle: React.CSSProperties = {
  display: "block",
  color: "#CBD5E1",
  marginBottom: 8,
  fontWeight: 600,
  fontSize: 14,
};

const inputStyle: React.CSSProperties = {
  width: "100%",
  height: 42,
  borderRadius: 8,
  border: "1px solid #334155",
  background: "#162130",
  color: "#FFF",
  padding: "0 12px",
  outline: "none",
  boxSizing: "border-box",
};

const selectStyle: React.CSSProperties = {
  width: "100%",
  height: 42,
  borderRadius: 8,
  border: "1px solid #334155",
  background: "#162130",
  color: "#FFF",
  padding: "0 12px",
  outline: "none",
  boxSizing: "border-box",
};

const textareaStyle: React.CSSProperties = {
  width: "100%",
  borderRadius: 8,
  border: "1px solid #334155",
  background: "#162130",
  color: "#FFF",
  padding: 12,
  outline: "none",
  resize: "vertical",
  fontFamily: "inherit",
  boxSizing: "border-box",
};