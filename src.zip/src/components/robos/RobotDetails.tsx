import {
  Bot,
  Calendar,
  GitBranch,
  Layers3,
  Pencil,
  Server,
  ShieldCheck,
  User,
} from "lucide-react";
import { Robot } from "./RobotTable";

interface RobotDetailsProps {
  robot: Robot | null;
  onEdit?: (robot: Robot) => void;
}

export default function RobotDetails({
  robot,
  onEdit,
}: RobotDetailsProps) {
  if (!robot) {
    return (
      <div
        style={{
          background: "#1E293B",
          border: "1px solid #273449",
          borderRadius: 14,
          height: "100%",
          display: "flex",
          justifyContent: "center",
          alignItems: "center",
          color: "#94A3B8",
        }}
      >
        Selecione um robô para visualizar os detalhes.
      </div>
    );
  }

  return (
    <div
      style={{
        background: "#1E293B",
        border: "1px solid #273449",
        borderRadius: 14,
        padding: 28,
        height: "100%",
        overflowY: "auto",
      }}
    >
      {/* Cabeçalho */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          marginBottom: 28,
        }}
      >
        <div
          style={{
            display: "flex",
            gap: 18,
            alignItems: "center",
          }}
        >
          <div
            style={{
              width: 64,
              height: 64,
              borderRadius: 14,
              background: "#233044",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Bot color="#60A5FA" size={30} />
          </div>

          <div>
            <h2
              style={{
                color: "#FFF",
                margin: 0,
                fontSize: 28,
              }}
            >
              {robot.nome}
            </h2>

            <div
              style={{
                color: "#94A3B8",
                marginTop: 6,
              }}
            >
              {robot.sistema}
            </div>
          </div>
        </div>

        <div
          style={{
            display: "flex",
            gap: 10,
          }}
        >

          <button
            onClick={() => onEdit?.(robot)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 8,
              padding: "10px 16px",
              borderRadius: 10,
              border: "1px solid #3B82F6",
              background: "#1D4ED8",
              color: "#FFF",
              cursor: "pointer",
              fontWeight: 600,
            }}
          >
            <Pencil size={16} />
            Editar
          </button>
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: 18,
        }}
      >
        <InfoCard
          icon={<GitBranch size={18} />}
          titulo="Ambiente"
          valor={robot.ambiente}
        />

        <InfoCard
          icon={<Calendar size={18} />}
          titulo="Última Publicação"
          valor={robot.ultimaPublicacao}
        />

        <InfoCard
          icon={<Layers3 size={18} />}
          titulo="Stack"
          valor={robot.stack}
        />

        <InfoCard
          icon={<Server size={18} />}
          titulo="Fila"
          valor={robot.fila}
        />

        <InfoCard
          icon={<Bot size={18} />}
          titulo="Versão"
          valor={robot.versao}
        />

        <InfoCard
          icon={<User size={18} />}
          titulo="Responsável"
          valor={robot.responsavel}
        />

        <InfoCard
          icon={<ShieldCheck size={18} />}
          titulo="Status"
          valor={robot.ativo ? "Ativo" : "Inativo"}
        />
      </div>

      <div
        style={{
          marginTop: 32,
          borderTop: "1px solid #273449",
          paddingTop: 24,
        }}
      >
        <h3
          style={{
            color: "#FFF",
            marginBottom: 12,
          }}
        >
          Descrição
        </h3>

        <p
          style={{
            color: "#94A3B8",
            lineHeight: 1.8,
            margin: 0,
          }}
        >
          {robot.descricao}
        </p>
      </div>
    </div>
  );
}

interface InfoCardProps {
  titulo: string;
  valor: string;
  icon: React.ReactNode;
}

function InfoCard({
  titulo,
  valor,
  icon,
}: InfoCardProps) {
  return (
    <div
      style={{
        background: "#162130",
        border: "1px solid #273449",
        borderRadius: 12,
        padding: 16,
      }}
    >
      <div
        style={{
          color: "#60A5FA",
          marginBottom: 10,
        }}
      >
        {icon}
      </div>

      <div
        style={{
          color: "#94A3B8",
          fontSize: 13,
        }}
      >
        {titulo}
      </div>

      <div
        style={{
          color: "#FFF",
          fontWeight: 600,
          marginTop: 6,
          wordBreak: "break-word",
        }}
      >
        {valor}
      </div>
    </div>
  );
}