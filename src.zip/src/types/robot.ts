export interface Robot {
  id: number;

  // Informações Gerais
  nome: string;
  sistema: string;
  pacote: string;
  ambiente: string;
  descricao: string;

  // Execução
  stack: string;
  fila: string;
  versao: string;

  // Administração
  responsavel: string;
  ultimaPublicacao: string;
  ativo: boolean;
}

export type RobotFormData = Omit<
  Robot,
  "id" | "ultimaPublicacao"
>;